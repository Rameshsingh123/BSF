# Click on next button Check without mail id

Email_txtbox = "//input[@placeholder='Email']"
Next_button = ".next-btn.md.button.button-solid.ion-activatable.ion-focusable.hydrated"

# Enter the invalid email id
error_message = ".error-message"

# enter the otp - Empty text box
otp_txtbox = "input[placeholder='Enter OTP']"
